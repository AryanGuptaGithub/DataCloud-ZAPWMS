// backend/src/models/Credential.js
const mongoose = require("mongoose");

/**
 * Option C: Each document = one CLIENT.
 * All domain/hosting services for that client live in services[].
 * This eliminates duplicate client_name records and allows
 * multiple domains + multiple hosting accounts per client.
 */
const ServiceSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: ["domain", "hosting"],
      required: [true, "Service type is required"],
      lowercase: true,
    },
    service_name: {
      type: String,
      required: [true, "Service name is required"],
      trim: true,
    },
    provider: {
      type: String,
      trim: true,
      default: "",
    },
    portal_url: {
      type: String,
      trim: true,
      default: "",
    },
    login: {
      type: String,
      trim: true,
      default: "admin",
    },
    password: {
      type: String,
      default: "",
    },
    expiry: {
      type: Date,
      default: null,
    },
    notes: {
      type: String,
      trim: true,
      default: "",
    },
  },
  {
    _id: true, // each service gets its own _id for targeted updates/deletes
    timestamps: true,
  }
);

const CredentialSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    client_name: {
      type: String,
      required: [true, "Client name is required"],
      trim: true,
      index: true,
    },
    services: {
      type: [ServiceSchema],
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

// Compound index: one client_name per user
CredentialSchema.index({ user: 1, client_name: 1 }, { unique: true });

module.exports = mongoose.model("Credential", CredentialSchema);