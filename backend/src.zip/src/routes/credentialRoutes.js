// backend/src/routes/credentialRoutes.js
const router = require("express").Router();
const ctrl = require("../controllers/credentialController");
const  protect  = require("../middleware/auth.js"); // adjust to your auth middleware name
 
/* ── Client-level routes ─────────────────────── */
router.get("/",                    protect, ctrl.listCredentials);
router.get("/upcoming-renewals",   protect, ctrl.listUpcomingRenewals);
router.get("/export",              protect, ctrl.exportCredentials);
router.post("/",                   protect, ctrl.createCredential);
router.get("/:clientId",           protect, ctrl.getCredential);
router.patch("/:clientId",         protect, ctrl.updateCredential);
router.delete("/:clientId",        protect, ctrl.deleteCredential);
 
/* ── Service-level routes ────────────────────── */
router.post("/:clientId/services",                       protect, ctrl.addServices);
router.put("/:clientId/services/:serviceId",             protect, ctrl.updateService);
router.delete("/:clientId/services/:serviceId",          protect, ctrl.deleteService);
router.delete("/:clientId/services",                     protect, ctrl.bulkDeleteServices);
 
module.exports = router;
 