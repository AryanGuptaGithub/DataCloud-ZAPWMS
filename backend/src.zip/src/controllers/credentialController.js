// backend/src/controllers/credentialController.js
const Credential = require("../models/Credential");

/* ─────────────────────────────────────────────
   GET /credentials
   Returns all client documents for the user,
   each with their full services array.
───────────────────────────────────────────── */
exports.listCredentials = async (req, res) => {
  try {
    const credentials = await Credential.find({ user: req.user._id }).sort({
      client_name: 1,
    });
    res.json(credentials);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   GET /credentials/:clientId
   Returns a single client document.
───────────────────────────────────────────── */
exports.getCredential = async (req, res) => {
  try {
    const credential = await Credential.findOne({
      _id: req.params.clientId,
      user: req.user._id,
    });
    if (!credential) {
      return res.status(404).json({ error: "Client record not found" });
    }
    res.json(credential);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   POST /credentials
   Creates a new client record (with optional
   initial services array).
   Body: { client_name, services: [...] }
───────────────────────────────────────────── */
exports.createCredential = async (req, res) => {
  try {
    const { client_name, services = [] } = req.body;

    if (!client_name || !client_name.trim()) {
      return res.status(400).json({ error: "client_name is required" });
    }

    // Check for duplicate client_name per user
    const exists = await Credential.findOne({
      user: req.user._id,
      client_name: client_name.trim(),
    });
    if (exists) {
      return res.status(409).json({
        error: `A record for "${client_name.trim()}" already exists. Use PATCH to add services.`,
        existingId: exists._id,
      });
    }

    const credential = await Credential.create({
      user: req.user._id,
      client_name: client_name.trim(),
      services,
    });

    res.status(201).json(credential);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        error: "A record for this client already exists.",
      });
    }
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   PATCH /credentials/:clientId
   Updates client_name only.
   Body: { client_name }
───────────────────────────────────────────── */
exports.updateCredential = async (req, res) => {
  try {
    const { client_name } = req.body;
    const update = {};
    if (client_name) update.client_name = client_name.trim();

    const credential = await Credential.findOneAndUpdate(
      { _id: req.params.clientId, user: req.user._id },
      update,
      { new: true, runValidators: true }
    );

    if (!credential) {
      return res.status(404).json({ error: "Client record not found" });
    }

    res.json(credential);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   DELETE /credentials/:clientId
   Deletes the entire client record (all services).
───────────────────────────────────────────── */
exports.deleteCredential = async (req, res) => {
  try {
    const credential = await Credential.findOneAndDelete({
      _id: req.params.clientId,
      user: req.user._id,
    });

    if (!credential) {
      return res.status(404).json({ error: "Client record not found" });
    }

    res.json({ success: true });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   POST /credentials/:clientId/services
   Adds one or more services to an existing client.
   Body: { services: [{ type, service_name, ... }] }
   Also accepts a single service object (not array).
───────────────────────────────────────────── */
exports.addServices = async (req, res) => {
  try {
    let newServices = req.body.services || req.body;
    if (!Array.isArray(newServices)) newServices = [newServices];

    const credential = await Credential.findOneAndUpdate(
      { _id: req.params.clientId, user: req.user._id },
      { $push: { services: { $each: newServices } } },
      { new: true, runValidators: true }
    );

    if (!credential) {
      return res.status(404).json({ error: "Client record not found" });
    }

    res.json(credential);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   PUT /credentials/:clientId/services/:serviceId
   Replaces a single service sub-document.
───────────────────────────────────────────── */
exports.updateService = async (req, res) => {
  try {
    const { clientId, serviceId } = req.params;

    // Build positional $set fields
    const setFields = {};
    const allowed = [
      "type", "service_name", "provider", "portal_url",
      "login", "password", "expiry", "notes",
    ];
    allowed.forEach((key) => {
      if (req.body[key] !== undefined) {
        setFields[`services.$.${key}`] = req.body[key];
      }
    });

    const credential = await Credential.findOneAndUpdate(
      {
        _id: clientId,
        user: req.user._id,
        "services._id": serviceId,
      },
      { $set: setFields },
      { new: true, runValidators: true }
    );

    if (!credential) {
      return res.status(404).json({ error: "Service not found" });
    }

    res.json(credential);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   DELETE /credentials/:clientId/services/:serviceId
   Removes one service. If it's the last service,
   optionally removes the whole client doc.
───────────────────────────────────────────── */
exports.deleteService = async (req, res) => {
  try {
    const { clientId, serviceId } = req.params;

    const credential = await Credential.findOneAndUpdate(
      { _id: clientId, user: req.user._id },
      { $pull: { services: { _id: serviceId } } },
      { new: true }
    );

    if (!credential) {
      return res.status(404).json({ error: "Client record not found" });
    }

    // Clean up empty client documents automatically
    if (credential.services.length === 0) {
      await Credential.findByIdAndDelete(clientId);
      return res.json({ success: true, clientDeleted: true });
    }

    res.json({ success: true, clientDeleted: false, credential });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   DELETE /credentials/:clientId/services (bulk)
   Removes multiple services by ID array.
   Body: { serviceIds: ["id1", "id2"] }
───────────────────────────────────────────── */
exports.bulkDeleteServices = async (req, res) => {
  try {
    const { clientId } = req.params;
    const { serviceIds = [] } = req.body;

    if (!serviceIds.length) {
      return res.status(400).json({ error: "serviceIds array is required" });
    }

    const credential = await Credential.findOneAndUpdate(
      { _id: clientId, user: req.user._id },
      { $pull: { services: { _id: { $in: serviceIds } } } },
      { new: true }
    );

    if (!credential) {
      return res.status(404).json({ error: "Client record not found" });
    }

    if (credential.services.length === 0) {
      await Credential.findByIdAndDelete(clientId);
      return res.json({ success: true, clientDeleted: true, deleted: serviceIds.length });
    }

    res.json({ success: true, clientDeleted: false, deleted: serviceIds.length });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   GET /credentials/upcoming-renewals?days=30
   Returns flat list of services expiring within N days.
───────────────────────────────────────────── */
exports.listUpcomingRenewals = async (req, res) => {
  try {
    const days = Number(req.query.days || 30);
    const today = new Date();
    const future = new Date();
    future.setDate(today.getDate() + days);

    const docs = await Credential.find({
      user: req.user._id,
      "services.expiry": { $gte: today, $lte: future },
    });

    // Flatten to service-level list
    const renewals = [];
    docs.forEach((doc) => {
      doc.services.forEach((svc) => {
        if (svc.expiry && svc.expiry >= today && svc.expiry <= future) {
          renewals.push({
            clientId: doc._id,
            client_name: doc.client_name,
            serviceId: svc._id,
            type: svc.type,
            service_name: svc.service_name,
            provider: svc.provider,
            expiry: svc.expiry,
          });
        }
      });
    });

    renewals.sort((a, b) => new Date(a.expiry) - new Date(b.expiry));
    res.json(renewals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

/* ─────────────────────────────────────────────
   GET /credentials/export
   Flat CSV-ready export of all services.
───────────────────────────────────────────── */
exports.exportCredentials = async (req, res) => {
  try {
    const docs = await Credential.find({ user: req.user._id });
    const rows = [];

    docs.forEach((doc) => {
      doc.services.forEach((svc) => {
        rows.push({
          client_name: doc.client_name,
          service_name: svc.service_name,
          type: svc.type,
          provider: svc.provider,
          portal_url: svc.portal_url,
          login: svc.login,
          password: svc.password,
          expiry: svc.expiry,
          notes: svc.notes,
        });
      });
    });

    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};